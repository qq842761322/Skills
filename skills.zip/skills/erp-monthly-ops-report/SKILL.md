---
name: erp-monthly-ops-report
description: 基于 ERP MCP 生成月度运营报表（管理层版），输出为单文件 HTML 网页。当用户要求"上个月运营报表""月度经营分析""运营报表改进/P1版""给老板看的运营报表""采销业务量货值报表""款票核对账龄"等，且数据源为 ERP（erp-mcp，珠海彤鑫/润天隆/极光等实例）时使用。**存在多个 erp-mcp 实例、而用户未指明或指代不明确时，必须先询问用户用哪个实例，严禁猜测、严禁多实例数据混用。** 覆盖：款票四类明细拉取、**合同类按月筛选（原生 contract_date_from/to 服务端筛选）**、测试数据识别与剥离、环比、净现金流、采销合同业务量与货值、预算对比框架、多币种、账龄与异常告警，最终产出可离线打开、可直接打印/转 PDF 的 HTML 报表。
agent_created: true
---

# ERP 月度运营报表（管理层版）· 网页输出

## 适用场景
用户要求生成/改进 ERP 月度运营报表，尤其面向管理层（含摘要、图表、环比、风险告警）。
**输出物固定为单文件 HTML 网页，不输出 Excel/xlsx。**

## 前置 A：多实例识别与选择（**强制 · 最高优先级 · 先于一切取数**）

本技能可能面对**多个 erp-mcp 实例**（如珠海彤鑫、珠海润天隆、极光，通常部署为多个 MCP server，工具名前缀形如 `mcp__erp-mcp__`、`mcp__erp-mcp-rtl__`、`mcp__erp-mcp-aurora__`）。

> **铁律：不确定用哪个实例时，必须停下来问用户。严禁猜测、严禁默认取第一个、严禁多实例数据混用。**

### 第 1 步 · 识别实例清单
枚举当前可用的 erp-mcp 相关 server（按工具名前缀归并），得到实例清单。
- 只有 **1 个** 实例 → 直接使用，无需询问。
- **≥2 个** 实例 → 进入第 2 步判定。

### 第 2 步 · 判定「是否已明确」
只有下列情形才算**明确**，可直接使用：
1. **用户本轮明确点名**了实例 / 公司 / 域名（如"珠海彤鑫""润天隆""极光""1.wanzhong-sc.com"）→ 用被点名的那个；
2. **本会话已确认过**同一实例且用户未改口 → 复用，并在回复中复述「本次使用：XXX」。

### 第 3 步 · 不明确 → **先问，后取数**
以下情形一律视为**不明确**，必须用 `AskUserQuestion` 询问，得到答复后才可动手：
- 用户只说"上个月运营报表""出个月报""给老板的报表"，未提及任何实例；
- 用户措辞含糊（如"那个主要的""上次那个"）而会话内无法确证指向；
- 没有任何此前的实例上下文，或上次确认已跨会话 / 相隔过久。

**询问模版**（选项即实例清单，带上公司全称 + 域名 + 版本辅助辨认；不要自填默认项）：
> 检测到 N 个 ERP 实例，本次运营报表取哪个实例的数据？
> - 珠海彤鑫科技有限公司（1.wanzhong-sc.com / v1.3.51.465）
> - 珠海润天隆（…）
> - 极光（…）

**用户回答之前，不得调用任何 `mcp__erp-mcp*__*` 取数接口。** 若连实例元信息（公司名/域名）也拿不到，就把 server 名原样列给用户让他选。

### 第 4 步 · 跨实例红线（绝不混用）
- **一份报表只允许来自一个实例**：款票、合同、币种等全部数据必须同源。
- **禁止**：把多个实例的金额相加、取并集、混排进同一张表 / 同一个图表；**禁止**用"默认 / 第一个 / 最近用过"的实例顶替用户未指明的那一个。
- 用户若明确要**多实例对比**：按实例**分区块呈现**（每实例独立一套指标与图表），**不得合并成一个数字**；并在摘要首条显著标注「本报表含 N 个实例，数据未合并」。
- 页头与「说明与口径」**必须写明实例**：公司全称 + 系统域名 + 版本，并注明「数据来源：单一实例 XXXX」或「多实例分列（未合并）」。

## 前置 B：ERP MCP 调用方式（关键）
ERP MCP 工具（`mcp__erp-mcp__*`）通常**未直接注入**当前工具集。调用方式固定为两步：
1. `ToolSearch(tool_names=[...])` 精确名加载 schema（不要用关键词搜索，容易漏）
2. `DeferExecuteTool(toolName="mcp__erp-mcp__xxx", params={...})`

若报 `result (N characters) exceeds maximum allowed tokens`，结果会**自动落盘**到
`~/.workbuddy/projects/<proj-slug>/<session-id>/tool-results/mcp-erp-mcp-*.txt`，用 Python `json.load` 解析（顶层结构 `{ok,total,page,page_size,items:[...]}`）。

> ⚠️ **参数以实时 schema 为准**：erp-mcp 会持续迭代（例：合同类后期新增了 `contract_date_from/to`）。**每次动工前必须用 `ToolSearch(tool_names=[...])` 重新加载 schema 核对入参**，不得凭历史记忆、旧会话日志或本技能的表格直接下结论；本技能表格仅作速查参考，与实时 schema 冲突时**以实时 schema 为准**。

## 核心接口与参数

### 款票四类（支持日期区间，月度报表主力）
| 用途 | 工具 | 日期参数 |
|---|---|---|
| 付款 | `finance_payment_detail_list` | `payment_date_from` / `payment_date_to` |
| 收款 | `finance_collection_detail_list` | `collection_date_from` / `collection_date_to` |
| 开票 | `finance_issued_invoice_detail_list` | `billing_date_from` / `billing_date_to` |
| 收票 | `finance_received_invoice_detail_list` | `invoice_date_from` / `invoice_date_to` |

日期格式 `YYYY-MM-DD`；单侧边界不得自行补齐。月度取整月，`page_size=100` 一次拉全。

### 合同类（**原生支持按月筛选**，直接用 `contract_date_from` / `contract_date_to`）
- 采购销售 8 个：`chrome_ore_*`（铬矿）、`ferrochrome_*`（铬铁）、`coke_*`（焦炭）、`methanol_*`（甲醇）；另加 `general_contract_list`（通用合同）。**共 9 个工具，参数完全一致。**
- **入参**：`keyword` / `status` / `branch_company` / **`contract_date_from` / `contract_date_to`** / `page` / `page_size`。
  - 日期格式 `YYYY-MM-DD`，**起止均含当日**（闭区间），取整月即 `2026-08-01` ~ `2026-08-31`。
  - **只有单侧边界时必须只传单侧**，不得自行补齐另一侧。
- ⚠️ **参数名统一，但语义不同**（同名参数落在不同视图字段上）：

| 品类 | 日期参数 | 实际筛选字段 | 说明 |
|---|---|---|---|
| 采购 4 类（`*_purchase_*`） | `contract_date_from/to` | `contract_date`（**合同日期**） | |
| 销售 4 类（`*_sales_*`） | `contract_date_from/to` | `signed_date`（**签约日期**） | 参数名仍叫 contract_date，但筛的是签约日期 |
| `general_contract_list` | `contract_date_from/to` | `contract_date`（合同日期） | |

- 字段名采购 / 销售**不同**，取值时按下表分流：

| 品类 | 日期字段 | 金额字段 | 数量字段 | 主键（ID）字段 |
|---|---|---|---|---|
| 铬矿采购 `chrome_ore_purchase_*` | `contract_date` | `contract_amount` | `contract_quantity` | `import_purchase_id` |
| 铬矿销售 `chrome_ore_sales_*` | `signed_date` | `contract_total_amount` | `contract_total_quantity` | `sales_contract_id` |
| 铬铁采销 `ferrochrome_*` | `signed_date` | `total_amount` | `total_quantity` | `contract_id` |
| 焦炭/甲醇 采销 | `signed_date`（无则 `contract_date`） | `total_amount` | `total_quantity` | `contract_id` |
| 通用合同 `general_contract_list` | `contract_date` | 见下方专节 | 见下方专节 | 逐一探测（见下） |

> **ID 字段别猜**：先取 `items[0].keys()` 找 `*_id` / `*_no`。已确认：铬矿采购=`import_purchase_id`、铬矿销售=`sales_contract_id`、铬铁采销/通用合同=`contract_id`。

#### 按月筛选：直接传日期区间（**唯一正确做法**）
```
调用(品类工具, contract_date_from="2026-08-01", contract_date_to="2026-08-31",
     page=1, page_size=100)   # 返回即为该月新增合同，无需本地再筛
```
实测确认（2026-09-11 复核）：
- `chrome_ore_purchase` 传 `2026-08-01~08-31` → `total=0`；传 `2026-06-01~06-30` → `total=1` 且命中 `R01502260626001`（`contract_date=2026-06-26`）✅
- `chrome_ore_sales` 传 `2023-10-01~10-31` → `total=3`，命中行 `signed_date` 均在 10 月 ✅（证明销售类确实按签约日期筛）
- `general_contract_list` 传 `2025-05-01~05-31` → `total=1`，命中 `R01650250509002`（`contract_date=2025-05-09`）✅

**注意**：
- 返回结果**已按月过滤**，不要再叠加本地月份过滤（多余且易出错）。
- 每页 `page_size` 建议 100；先看 `total` 决定是否需要翻页，`total ≤ 100` 一次即可拿全（月度新签通常远小于此）。
- **不要**因为"接口规则说不得自动翻页"就不分页：月度报表只取目标月，`total` 很小；仅当 `total > page_size` 时才翻到 `ceil(total/page_size)` 页。
- 口径合规：工具规则要求"仅在用户明确提供日期范围时填写"——**月度报表的目标月本身就是明确的日期范围**，传整月区间合规；但**不得**在用户没给月份时自行猜一个区间。

#### 已废弃做法（不要再用）
- ❌ **游标扫描法**（逐页倒序推进 + 本地按月过滤）：接口已支持服务端日期筛选，此法多余、慢且易触发翻页限制。
- ❌ **"只看第一页 page_size=5"判空**：现在直接传月份区间看 `total` 即可，精确且更便宜。
- ❌ **用 `keyword` 筛日期**：合同 ID 内嵌日期与 UI 日期不一致（如 `R01502240726001` 内嵌 07-26、实际 `contract_date`=07-17），命中率仅 20%~60%。`keyword` 仅用于用户明确给出编号/客户/货物时检索。

### 通用合同 `general_contract_list`（月度报表重点）
- 字段：`contract_date` / `contract_amount` / `contract_quantity` / `payment_amount` / `collection_amount` / `received_invoice_amount` / `issued_invoice_amount` / `fund_amount` / `invoice_amount` / `fund_invoice_equal_status` / `cargo_value` / `area`
- 除按月筛选外，**款票核对需取累计口径**（关注全量而非某月）时，可用 `page_size=100` 拉全（全量仅约 82 条、品类单一：洗厂原料采购 / 无票支出），再本地汇总。
- 款票差异取数：**已付款 `payment_amount`、已收票 `received_invoice_amount`**（实测两者分别与 `fund_amount`、`invoice_amount` 同值，建议以 `payment_amount` / `received_invoice_amount` 为准；差异状态见 `fund_invoice_equal_status`）。

## 测试数据识别规则（三信号，缺一不可）
判定为「测试数据」需满足任一：
1. `confirmation_id` 以 `SM2608` 开头（安全模式测试批次）
2. 经办人 `created_by` / `prepared_by` 含「测试」（如"付款审批测试001"）
3. **合同/分类名含「测试」**（易漏！如合同名"测试上下游开票信息"）

其余按「真实业务」处理。对真实业务中客户名为 `333/546/8888/5654` 或金额为重复数字（如 ¥1,111,111.00）的，加「异常标记」标注存疑。

## 报表内容结构（网页章节，自上而下）
1. **页头** — 公司全称/**实例名**/系统域名+版本/报表名/期间/编制时间；多实例时标注「N 个实例 · 未合并」
2. **管理层摘要** — 6 条核心结论（结论先给）+ 6 个 KPI 卡片（真实口径）+ 分级风险待办
3. **KPI 看板** — 真实口径 & 全口径双段环比表 + 柱状图
4. **现金流概览** — 收/付/开票/收票 × 本月真实/测试/合计 × 上月 + 净现金流 + 柱状图
5. **采销业务量货值** — 各品类合同总数/**本月新签（按 `contract_date_from/to` 服务端筛选得出）**/最近日期/业务量/货值 + 在途货值汇总
6. **预算对比** — 结构 + 完成率，预算列标「待补」（ERP 无预算接口）
7. **币种分析** — 币种/笔数/原币/折人民币/占比 + 饼图
8. **款票核对账龄** — 通用合同款票差异清单 + 款票时间分布
9. **异常告警** — 分级（高/中/低）+ 处置建议
10. **明细表** — 付款/收款/开票/收票 本月 + 付款/收票 上月（环比基准），含「数据性质」标色列；明细默认折叠（`<details>`）
11. **说明与口径** — **数据来源实例（公司全称/域名/版本，单一实例 or 多实例未合并）**、口径定义、已知局限

## 网页输出规范（核心）
- **交付物**：`<工作区>/YYYY年M月运营报表_P1.html` —— **单文件自包含**，双击即可离线打开。
- **生成方式**：写 Python 脚本建 HTML 字符串（不用 xlsx/openpyxl，不用模板引擎），脚本存 `<工作区>/.YYYY年M月运营报表_P1.ref/build_html.py`。
- **必须自包含**：CSS 内联在 `<style>`；数据以 `const DATA = {...}` 内联在 `<script>`。
- **图表**：默认内联 **Chart.js（CDN）**，`<script src="https://cdn.jsdelivr.net/npm/chart.js@4">`；
  - 若用户明确要求**完全离线/内网**，降级为 **Python 直出内联 SVG**（柱状/饼/折线各写一个生成函数，零依赖）；
  - 无论哪种，图表容器必须给固定高度，否则不渲染。
- **布局与样式**：
  - 浅色主题：页面底 `#f5f7fa`，卡片白底 + 1px `#e5e8ee` 边框 + 轻微圆角与阴影，正文 `#262626`
  - 顶部**粘性导航**（`position:sticky`）锚点跳转到各章节；章节标题带左侧色条
  - KPI 卡片用 CSS Grid（`repeat(auto-fit,minmax(220px,1fr))`），大数字 20–24px 加粗
  - 表格：表头深蓝 `#1f4e79` 白字、斑马纹 `#f6f9fc`、数字右对齐、金额千分位
  - **配色语义**（沿用，别改成股价涨跌色）：真实/正常 = 绿 `#c6efce`；异常/测试 = 红 `#ffc7ce`；存疑/待补 = 黄 `#ffeb9c`
  - 中文字体栈：`"Microsoft YaHei","PingFang SC","Hiragino Sans GB",sans-serif`
- **响应式 + 打印**：
  - 宽度 ≤768px 时 KPI 单列、表格横向滚动（外层 `overflow-x:auto`）
  - 加 `@media print { … }`：隐藏导航与折叠按钮，`-webkit-print-color-adjust:exact` 保留底色，便于老板直接「打印为 PDF」
- **不要**：不要引用本地相对路径的图片/字体/JS（除 CDN）；不要留 TODO 占位；数值一律脚本内算好后写入，**不要在页面里用 JS 做业务计算**。

## 执行清单
0. **先定实例**：枚举 erp-mcp 实例；≥2 个且用户未明确 → `AskUserQuestion` 问清并用用户答案，**未回答前不取任何数**；全程只用单一实例，禁止混用（见「前置 A」）
1. ToolSearch + DeferExecuteTool 拉款票四类（本月 + 上月）——**全部限定在同一实例**
2. 各合同品类**按月筛选**（9 个工具均支持 `contract_date_from` / `contract_date_to`，格式 `YYYY-MM-DD`、含当日）：
   - 传目标月整月区间（如 `2026-08-01` ~ `2026-08-31`），`page_size=100`；`total ≤ 100` 一次拿全，否则翻到 `ceil(total/page_size)` 页
   - 销售类工具同名参数筛的是**签约日期** `signed_date`，采购类筛 `contract_date`（见接口表）
   - **不要**再本地过滤月份；**不要**用 keyword 或"只看第一页"代替
3. 按三信号分类真实/测试，计算：付款、收款、开票、收票、净现金流、环比
4. 通用合同款票差异（`payment_amount` vs `received_invoice_amount`）与货值（`cargo_value`）
5. 写 `build_html.py` → 运行生成 HTML → 用 Read/Grep 回读校验关键数值已写入
6. 预算列留「待补」并在摘要中明确说明缺口
7. `present_files` 展示 HTML（会自动开实时预览）
8. 回复中复述「本次使用实例：XXX」，便于用户纠偏

## 注意
- **多实例第一原则**：用户未指明实例时**先问再做**；宁可停一轮，也不猜、不混、不合并。
- **合同类按月筛选**：用原生 `contract_date_from` / `contract_date_to`（`YYYY-MM-DD`、含当日、整月区间），服务端已过滤，**不要再本地筛月**；销售类同名参数筛的是签约日期 `signed_date`。
- 月份若无真实业务，**照实呈现**（不要粉饰），并在摘要给出「业务是否在其他实例/未入系统」的核实建议。
- 严禁混淆真实业务与测试数据；两者必须分色并可区分。
- 报表是给老板看的：**结论先行**，数字要有千分位与单位，异常要有处置建议。
- 权限错误即停止，不重试。
